# ezShopping
Shopping List for Windows, macOS, iOS, Android and Smart Watches
